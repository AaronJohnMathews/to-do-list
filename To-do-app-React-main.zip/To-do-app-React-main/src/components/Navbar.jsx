import React from 'react'

export default function Navbar() {
  return (
    <div className="navbar bg-base-100">
    <a className="btn btn-ghost text-xl">daisyUI</a>
  </div>
  )
}
